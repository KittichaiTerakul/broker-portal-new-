package com.example.ProjectAllianz.repository;

import com.example.ProjectAllianz.entity.FundInformation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FundInformationRepository extends JpaRepository<FundInformation,Integer> {
}
