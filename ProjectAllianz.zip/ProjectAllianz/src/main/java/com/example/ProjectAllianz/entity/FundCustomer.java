package com.example.ProjectAllianz.entity;


import javax.persistence.*;

@Entity
@Table(name="fundCustomer")
public class FundCustomer {

    @Id

    @Column
    private int fundcustomerId;

    @ManyToOne
    @JoinColumn(name = "quote_id")
    private Quote quote;

    @Column
    private int fundId;


    @Column
    private int percentage;



    public int getFundcustomerId() {
        return fundcustomerId;
    }

    public void setFundcustomerId(int fundcustomerId) {
        this.fundcustomerId = fundcustomerId;
    }

    public Quote getQuote() {
        return quote;
    }

    public void setQuote(Quote quote) {
        this.quote = quote;
    }

    public int getFundId() {
        return fundId;
    }

    public void setFundId(int fundId) {
        this.fundId = fundId;
    }

    public int getPercentage() {
        return percentage;
    }

    public void setPercentage(int percentage) {
        this.percentage = percentage;
    }
}
