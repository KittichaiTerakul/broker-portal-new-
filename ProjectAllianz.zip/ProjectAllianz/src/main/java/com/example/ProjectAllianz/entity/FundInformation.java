package com.example.ProjectAllianz.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "fund")
public class FundInformation {

    @Id
    @Column
    private int fundId;

    @Column
    private String fundName;


    @Column
    private int riskIndicator;

    @Column
    private int rating;


    public int getFundId() {
        return fundId;
    }

    public void setFundId(int fundId) {
        this.fundId = fundId;
    }

    public String getFundName() {
        return fundName;
    }

    public void setFundName(String fundName) {
        this.fundName = fundName;
    }



    public int getRiskIndicator() {
        return riskIndicator;
    }

    public void setRiskIndicator(int riskIndicator) {
        this.riskIndicator = riskIndicator;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
