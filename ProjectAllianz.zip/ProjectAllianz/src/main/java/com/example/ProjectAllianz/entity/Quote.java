package com.example.ProjectAllianz.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="quote")
public class Quote {
    @Id


//    @GeneratedValue(strategy = GenerationType.AUTO)
//    @SequenceGenerator(name="id", initialValue=5, allocationSize=100)
//    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="quoteId")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column
    private String quoteId;

    @Column
    private String firstName;

    @Column
    private String lastName;

    @Column
    private String gender;

    @Column
    private Date dateOfBirth;

    @Column
    private String preferredLanguages;

    @OneToMany
    private FundCustomer fundCustomer;




    public void setId(int id) {
        this.id = id;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }



    public String getPreferredLanguages() {
        return preferredLanguages;
    }

    public void setPreferredLanguages(String preferredLanguages) {
        this.preferredLanguages = preferredLanguages;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
