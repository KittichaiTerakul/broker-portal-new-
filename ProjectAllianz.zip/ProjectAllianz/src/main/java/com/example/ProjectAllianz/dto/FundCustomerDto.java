package com.example.ProjectAllianz.dto;

public class FundCustomerDto {

    private int quoteQuoteId;
    private int fundId;
    private int percent;


    public int getQuoteQuoteId() {
        return quoteQuoteId;
    }

    public void setQuoteQuoteId(int quoteQuoteId) {
        this.quoteQuoteId = quoteQuoteId;
    }

    public int getFundId() {
        return fundId;
    }

    public void setFundId(int fundId) {
        this.fundId = fundId;
    }

    public int getPercent() {
        return percent;
    }

    public void setPercent(int percent) {
        this.percent = percent;
    }
}
